Entity type: person name

Markup: 
`<name>XXX</name>`

For example, "Elon Musk has three wives". 

`"<name >Elon</name> <name>Musk</name> has three wives."`
